CS8461 OPERATING SYSTEM LABORATORY was handled by C.Gomathi and S.usha for 2nd Year IT-B [2019-march]
Staff Name-C.Gomathi
Email id- Gomathi.m.e@gmail.com 

Staff Name-S.Usha 
Email id-Ushaanbu2014@gmail.com

syllabus 


LIST OF EXPERIMENTS

1. Basics of UNIX commands

2. Write programs using the following system calls of UNIX operating system fork, exec, getpid, exit, wait, close, stat, opendir, readdir

3. Write C programs to simulate UNIX commands like cp, ls, grep, etc.

4. Shell Programming

5. Write C programs to implement the various CPU Scheduling Algorithms

6. Implementation of Semaphores

7. Implementation of Shared memory and IPC

8. Bankers Algorithm for Deadlock Avoidance

9. Implementation of Deadlock Detection Algorithm

10. Write C program to implement Threading & Synchronization Applications

11. Implementation of the following Memory Allocation Methods for fixed partition

a) First Fit b) Worst Fit c) Best Fit

12. Implementation of Paging Technique of Memory Management

13. Implementation of the following Page Replacement Algorithms

a) FIFO b) LRU c) LFU

14. Implementation of the various File Organization Techniques

15. Implementation of the following File Allocation Strategies

a) Sequential b) Indexed c) Linked

                                                                                                      TOTAL: 60 PERIODS

OUTCOMES:

At the end of the course, the student should be able to

Compare the performance of various CPU Scheduling Algorithms
Implement Deadlock avoidance and Detection Algorithms
Implement Semaphores
Create processes and implement IPC
Analyze the performance of the various Page Replacement Algorithms
Implement File Organization and File Allocation Strategies
